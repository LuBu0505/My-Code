package com.example;

/**
 * Hello world!
 *
 */ 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication; 
import org.redisson.api.RSet;
import org.redisson.api.RedissonClient; 
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

 

@SpringBootApplication
@RestController
public class App {
        
    @Autowired
    private RedissonClient redisson;
    
    public static void main(String[] args) {
        SpringApplication.run(App.class, args);

        System.out.println("Hello World!");
    }

    @RequestMapping("/redis/{key}")
    String SetGetRedis(@PathVariable String key){
        //Set the Key to Redis Service.
        RSet<String> set = redisson.getSet(key);
        set.add("Test value from Redisson Application ... ");

        //Return the Vlaue to Page 
          return set.toString();
    }
}